import java.util.*;

public class BookData {
    public static List<Book> getBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book("Java Programming", "ABC", "Programming", 500, true));
        books.add(new Book("Effective Java", "DEF", "Programming", 600, true));
        books.add(new Book("Harry Potter", "JHI", "Fiction", 300, false));
        books.add(new Book("The Alchemist", "KLM", "Fiction", 400, true));
        books.add(new Book("Database Systems", "C.J. Date", "Database", 700, true));
        return books;
    }
}
