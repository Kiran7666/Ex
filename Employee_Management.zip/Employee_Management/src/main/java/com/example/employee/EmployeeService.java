package com.example.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    @Autowired
	private EmployeeRepository employeerepository;
    
    public List<Employee> getAllEmployee(){
    	
    	return employeerepository.findAll()!=null?employeerepository.findAll():null;
    }
    
    public Employee getEmpById(Long Id) {
    	
    	return employeerepository.getById(Id);
    }
    
    public Employee addEmployee(Employee employee) {
    	
    	return employeerepository.save(employee);
    }
	
	public void deleteEmployee(Long id) {
		Employee emp=getEmpById(id);
		employeerepository.delete(emp);
	}
	
	public Employee updateEmployee(Long Id, Employee e) {
		Employee emp=getEmpById(Id);
		emp.setFirstName(e.getFirstName());
		emp.setLastName(e.getLastName());
		emp.setEmail(e.getEmail());
		emp.setPhoneNumber(e.getPhoneNumber());
		emp.setPosition(e.getPosition());
		emp.setSalary(e.getSalary());
		
		return employeerepository.save(emp);
	}
}
