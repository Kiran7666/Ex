package com.example.bookstore;

import java.util.ArrayList;
import java.util.List;

public class Bookstore {
    private List<Book> books;

    public Bookstore() {
        books = new ArrayList<>();
        // Sample data
        books.add(new Book("Placement Times", "Author 1", "Fiction", 29.99, true));
        books.add(new Book("Library Katta", "Author 2", "Non-Fiction", 19.99, false));
        books.add(new Book("College DAZE", "Author 3", "Science", 39.99, true));
        // Add more books as needed
    }

    public List<Book> getBooks() {
        return books;
    }

    public void addBook(Book book) {
        books.add(book);
    }
}
